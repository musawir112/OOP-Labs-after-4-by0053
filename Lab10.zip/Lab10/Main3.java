class Main3{
	public static void main(String[] args) {
		 FullTimeEmployee fte = new FullTimeEmployee("Ali", 101, 4000);
        PartimeEmployee pte = new PartimeEmployee("Shah", 202, 20, 80);

         System.out.println("Salary of " + fte.name + ": $" + fte.calculateSalary());
         fte.payTax();

         System.out.println("Salary of " + pte.name + ":" + pte.calculateSalary());
         pte.payTax();


	}
}