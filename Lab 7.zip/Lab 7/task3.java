import java.util.Scanner;

public class task3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        String[] strings = new String[5];
        
        System.out.println("Enter 5 strings:");
        for (int i = 0; i < 5; i++) {
            strings[i] = scanner.nextLine();
        }
        
        System.out.println("\nUppercase Strings:");
        for (int i = 0; i < 5; i++) {
            System.out.println(strings[i].toUpperCase());
        }
        
        scanner.close();
    }
}