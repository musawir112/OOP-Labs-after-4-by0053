interface Vehical{
	public void start();
	public void stop();
}