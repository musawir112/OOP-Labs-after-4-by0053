class Main1{
	public static void main(String[] args) {
		Dog b=new Dog();

		Cat c=new Cat();

		b.makeSound();
		c.makeSound();
		c.eat();
	}
}