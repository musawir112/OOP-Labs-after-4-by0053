class Dog extends Animal{
	
	void makeSound()
	{
		System.out.println("Barks Barks");
	} 

	void eat()
	{
		System.out.println("Animal is eating");
	}
}