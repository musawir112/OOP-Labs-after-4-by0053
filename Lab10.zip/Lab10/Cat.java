class Cat extends Animal{
	
	void makeSound()
	{
		System.out.println("Mayao");
	}

	void eat()
	{
		System.out.println("Animal is eating");
	}
}