import java.util.Scanner;
//Task 6 is this //
public class task5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter a string: ");
        String userInput = scanner.nextLine();
        
        if (userInput.contains("Java")) {
            System.out.println("String contains Java");
        } else {
            System.out.println("String does not contain Java");
        }

        scanner.close();
    }
}