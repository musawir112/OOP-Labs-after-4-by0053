class Rectangle extends Shape{


	void draw(){
		super.draw();
		System.out.println("Drawing a Rectangle");
	}
}