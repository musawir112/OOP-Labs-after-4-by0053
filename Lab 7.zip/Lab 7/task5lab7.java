import java.util.Scanner;

public class Task_5 {
    public static void main(String[] args) {
        
        Scanner check = new Scanner(System.in);
        
        
        System.out.print("Enter a string: ");
        String input = check.nextLine();
        
        
        if (input.endsWith("world")) {
            System.out.println("String ends with world");
        } else {
            System.out.println("String does not end with world");
        }
        

    }
}