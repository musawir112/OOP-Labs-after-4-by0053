class Cat extends Animal{

	void makeSound()
	{
		System.out.println("Cat meows");
	}
}