import java.util.Scanner;

public class Task_2 {


    public static void main(String args[]) {
       Scanner input = new Scanner(System.in);
    
       System.out.println("Enter a String");
       String check = input.nextLine();
       
       int index  = check.indexOf('b');
    
    	System.out.println("The Index Of b : " + index);
    
    
    
    
    
    
    
    }
}