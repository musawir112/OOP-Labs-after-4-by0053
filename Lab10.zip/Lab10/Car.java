class Car implements Vehical {
	public void start()
	{
		System.out.println("Car Start ");
	}

	public void stop()
	{
		System.out.println("Car Stop");
	}
}