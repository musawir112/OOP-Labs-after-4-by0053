class Bike implements Vehical {
	public void start()
	{
		System.out.println("Bike Start");
	}

	public void stop()
	{
		System.out.println("Bike Stop");
	}
}