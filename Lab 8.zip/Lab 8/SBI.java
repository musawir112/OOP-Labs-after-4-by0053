class SBI extends Bank{
	double getInterestRate()
	{
		return 7.5;
	}
}