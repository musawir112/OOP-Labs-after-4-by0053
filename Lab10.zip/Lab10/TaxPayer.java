interface TaxPayer{

	public void payTax();

}