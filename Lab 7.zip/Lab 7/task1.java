import java.util.Scanner;

public class Task_1 {


    public static void main(String args[]) {
       Scanner input = new Scanner(System.in);
    
       System.out.println("Enter a String");
       String check = input.nextLine();
       
       if(check.isEmpty()){
           System.out.println("String is Empty!");
       }
       else{
       
           System.out.println("String is Not Empty!");
       
       }
    
    
    
    
    
    
    
    
    
    }
