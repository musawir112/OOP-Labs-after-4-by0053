import java.util.Scanner;

public class task7{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter a string: ");
        String userInput = scanner.nextLine();
        
        String modifiedString = userInput.replace(' ', '');
        
        System.out.println("Modified string: " + modifiedString);

s        scanner.close();
    }
}