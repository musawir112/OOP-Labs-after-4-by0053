class Main1{
	public static void main(String []args){
	GraduateStudent p=new GraduateStudent("Safeeullah",21,"ARI-F24-0080","AI Based Operating System");

	p.displayInfo();
	}
}