class Main3{
	public static void main(String []args){
		Car m=new Car("RollsRoyles","250 m/s",4);
		m.showDetails();
		System.out.println();
		System.out.println();
		Bike b=new Bike("Yamaha","250m/s", "Full-Face Helmets");
		b.showDetails();
	}
}