class Circle extends Shape{
	


	void draw(){
		super.draw();
		System.out.println("Drawing Circle");
	}
}