import java.util.Scanner;

public class task8 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter a string: ");
        String userInput = scanner.nextLine();
        
        String[] words = userInput.split(" ");
        
        int wordCount = 0;
        for (String word : words) {
            System.out.println(word);
            wordCount++;
        }
        
        System.out.println("Total words: " + wordCount);
        
        scanner.close();
    }
}