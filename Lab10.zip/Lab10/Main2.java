class Main2{
	public static void main(String[] args) {
		Rectangle r=new Rectangle(4.5,3.5);

		double Area=r.area();

		System.out.println("Area: "+Area);

		r.print();
	}
}